package com.example.demo.Entity;

public class DeleteUser {
	String tablename;
	String name;
	public DeleteUser() {
		super();
	}
	public DeleteUser(String tablename, String name) {
		super();
		this.tablename = tablename;
		this.name = name;
	}
	@Override
	public String toString() {
		return "DeleteUser [tablename=" + tablename + ", name=" + name + "]";
	}
	public String getTablename() {
		return tablename;
	}
	public void setTablename(String tablename) {
		this.tablename = tablename;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
