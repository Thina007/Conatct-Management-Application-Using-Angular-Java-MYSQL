package com.example.demo.Entity;

public class UserContactRecord {
	
	String tablename;
	String name;
	String phoneNumber;
	String mail;
	public UserContactRecord() {}
	public UserContactRecord(String tablename, String name, String phoneNumber, String mail) {
		this.tablename = tablename;
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.mail = mail;
	}
	@Override
	public String toString() {
		return "UserContactRecord [tablename=" + tablename + ", name=" + name + ", phoneNumber=" + phoneNumber
				+ ", mail=" + mail + "]";
	}
	public String getTablename() {
		return tablename;
	}
	public void setTablename(String tablename) {
		this.tablename = tablename;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
}
