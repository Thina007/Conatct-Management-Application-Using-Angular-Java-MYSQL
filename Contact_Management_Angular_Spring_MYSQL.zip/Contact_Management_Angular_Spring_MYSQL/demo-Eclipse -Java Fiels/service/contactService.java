package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.Entity.DeleteUser;
import com.example.demo.Entity.Login;
import com.example.demo.Entity.UserContactRecord;
import com.example.demo.repository.ContactDao;
import com.manageengine.apminsight.agent.api.ApmTracker;

@Service
public class contactService {
	
	
	
	
	public String saveContact(UserContactRecord user) {
		ContactDao cd= new ContactDao();
		return cd.insertUserRecord(user.getTablename(), user.getName(), user.getPhoneNumber(), user.getMail());
	}
	
	public String login(Login user) {
		ContactDao cd= new ContactDao();
		return cd.check(user.getName(), user.getPassword());
	}
	
	
	public String signin(Login user) {
		ContactDao cd= new ContactDao();
		cd.createTable(user.getName());
		return cd.insertUser(user.getName(), user.getPassword());
	}

	public String insertUserRecord(UserContactRecord user) {
		//System.out.println("User Table"+user.getTablename());
		ContactDao cd= new ContactDao();
		return cd.insertUserRecord(user.getTablename(), user.getName(), user.getPhoneNumber(), user.getMail());
	}

	public String deleteUser(DeleteUser user) {
		ContactDao cd= new ContactDao();
		return cd.deleteRecord(user.getTablename(), user.getName());	
	}
	
	@ApmTracker(name="updateUser_$1")
	public String updateUserRecord(UserContactRecord user) {
		//System.out.println("2nd Stage of Working in Update");
		ContactDao cd= new ContactDao();
		return cd.editForm(user.getTablename(), user.getName(), user.getPhoneNumber(), user.getMail());
	}

	public String deleteAccount(Login lg) {
		ContactDao cd= new ContactDao();
		cd.deleteUserAccount(lg.getName());
		return cd.deleteAccount(lg.getName());
	}
	

}
