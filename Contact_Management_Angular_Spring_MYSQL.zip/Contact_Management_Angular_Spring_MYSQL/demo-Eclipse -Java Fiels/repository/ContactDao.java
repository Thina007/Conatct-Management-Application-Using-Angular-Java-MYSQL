package com.example.demo.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.example.demo.Entity.UserContactRecord;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.manageengine.apminsight.agent.api.ApmTracker;
import com.manageengine.apminsight.agent.api.CustomTracker;

@Component

public class ContactDao {
	
	 String url = "jdbc:mysql://localhost:3306/minProject";
	 String username = "root";
	 String password = "thina33";
	 ObjectMapper mapper = new ObjectMapper();  
	 Connection con;
	public void common() 
	{
		 try {
			 
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url,username, password);
		} catch (Exception e) {}
		 
	}
	public String check(String name,String pass) 
	{
		try {
			String sql =  "select * from customer where name='"+name+"' and password='"+pass+"'";
			common();
			PreparedStatement st=con.prepareStatement(sql);
			ResultSet rs=st.executeQuery();
			if(rs.next())
			{
				try {
					return mapper.writeValueAsString(name);
				} catch (JsonProcessingException e) {}
				
			}
		}
		catch(Exception e) {}
		return "";
	}
	
	@ApmTracker(name="insertUser_$1")
    public String insertUser(String name,String password)
    {
    	try {
    	String sql =  "insert into customer values('"+name+"','"+password+"')";
    	common();
		PreparedStatement st=con.prepareStatement(sql);
		int rs=st.executeUpdate();
		if(rs!=0)
		{
			try {
				return mapper.writeValueAsString(name);
			} catch (JsonProcessingException e) {}
		}
    	}catch(Exception e) {}
    	return "";
    }
    
	@ApmTracker(name="insertUserRecord_$1")
    public String insertUserRecord(String tname,String name,String phone,String mail)
    {
    	try
    	{
    		//System.out.println("Table"+tname+name+phone+mail);
    		String sql =  "insert into "+tname+" values('"+name+"','"+phone+"','"+mail+"');";
    		common();
    		PreparedStatement st=con.prepareStatement(sql);
    		int rs=st.executeUpdate();
    		if(rs!=0)
    		{
    			try {
    				return mapper.writeValueAsString(tname);
    			} catch (JsonProcessingException e) {}
    		}
    	}catch(Exception e) {}
    	return "";
    }
    
	@ApmTracker(name="createTable_$1")
	public boolean createTable(String name) {
		
		try
		{
			String sql="Create table "+name+"(name varchar(30) PRIMARY KEY,phonenumber varchar(30),mail varchar(30));";
			common();
			PreparedStatement st = con.prepareStatement(sql);
			st.execute(sql);
		}catch(Exception e) {};
		return true;
	}
	
	@ApmTracker(name="updateUser_$1")
	public String editForm(String tname,String name, String phonenumber, String mail) {
		
		try
		{
			//System.out.println("3rd Stage of Update is working"+tname+name+phonenumber+mail);
			String sql="UPDATE "+tname +" SET mail='"+mail+"',phonenumber="+phonenumber+" WHERE name='"+name+"';";
			common();
			PreparedStatement st = con.prepareStatement(sql);
			int n=st.executeUpdate(sql);
			if(n!=0)
			{
				try {
					return mapper.writeValueAsString(tname);
				} catch (JsonProcessingException e) {}
			}
		}
		catch(Exception e) {
			CustomTracker.trackException(e);
		}
		
		return "";
	}

	@ApmTracker(name="deleteRecord_$1")
	public String deleteRecord(String tname, String name) {
		try
		{
			String sql="Delete from "+tname +" WHERE name='"+name+"';";
			common();
			
			System.out.println("This is Delete  Record");
			PreparedStatement st = con.prepareStatement(sql);
			int n=st.executeUpdate(sql);
			if(n!=0)
			{
				try {
					return mapper.writeValueAsString(tname);
				} catch (JsonProcessingException e) {}
			}
		}
		catch(Exception e) {}
		
		return "";
	}
	
	@ApmTracker(name="ViewAll_$1")
	public String viewAllRecord(String name)
	{
		try {
		String sql="Select * from "+name;
		common();
		PreparedStatement st=con.prepareStatement(sql);
		ResultSet rs=st.executeQuery();
		List list=new ArrayList<UserContactRecord>();
		while(rs.next())
		{
			UserContactRecord us = new UserContactRecord();
			us.setName(rs.getString(1));
			us.setPhoneNumber(rs.getString(2));
			us.setMail(rs.getString(3));
			list.add(us);
		}
		try {
			return mapper.writeValueAsString(list);
		} catch (JsonProcessingException e) {}
		
		}catch(Exception e) {};
		return "";
	}
	
	@ApmTracker(name="DeleteAccount_$1")
	public String deleteAccount(String tname) {
		try
		{
			String sql="Drop table "+tname+";";
			common();
			PreparedStatement st = con.prepareStatement(sql);
			int n=st.executeUpdate();
			if(n!=0)
			{
				return tname;
			}
		}
		catch(Exception e) {}
		
		return "";
	}
	public boolean deleteUserAccount(String tname) {
		try
		{
			String sql="delete from customer where name='"+tname+"';";
			common();
			PreparedStatement st = con.prepareStatement(sql);
			int n=st.executeUpdate();
			if(n!=0)return true;
		}
		catch(Exception e) {}
		
		return false;
	}
	public boolean checkUser(String name) {
		try
		{
			String sql="select * from customer where name='"+name+"';";
			common();
			PreparedStatement st =con.prepareStatement(sql);
			ResultSet rs=st.executeQuery();
			if(rs.next())return true;
		}
		catch(Exception e) {}
		return false;
	}
}
