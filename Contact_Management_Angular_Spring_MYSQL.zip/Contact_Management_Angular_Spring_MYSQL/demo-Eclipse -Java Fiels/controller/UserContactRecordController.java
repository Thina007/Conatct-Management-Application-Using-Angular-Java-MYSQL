package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.DeleteUser;
import com.example.demo.Entity.Login;
import com.example.demo.Entity.UserContactRecord;
import com.example.demo.repository.ContactDao;
import com.example.demo.service.contactService;
import com.manageengine.apminsight.agent.api.ApmTracker;
import com.manageengine.apminsight.agent.api.CustomTracker;

@CrossOrigin("http://localhost:4200")
@RestController
public class UserContactRecordController {
	@Autowired
	contactService cs;

	@PostMapping("/deleteAccount")
	public String DeleteAccount(@RequestBody Login lg)
	{
		return cs.deleteAccount(lg);
	}
	

	@PostMapping("/login")
	public String Login(@RequestBody Login lg) 
	{
		  return cs.login(lg);
	}

	
	@PostMapping("/signing")
	public String Signin(@RequestBody Login user)
	{
		 return cs.signin(user);
	}
	
	@PostMapping("/adduser")
	public String AddUser(@RequestBody UserContactRecord user) 
	{
		 String str=cs.insertUserRecord(user);
		 return str;
	}
	
	
	@ApmTracker(name="updateUser_$1")
	@PostMapping("/updateuser")
	public String UpdateUser(@RequestBody UserContactRecord user) 
	{
		 return cs.updateUserRecord(user);
	}
	
	@PostMapping("/deleteuser")
	public String DeleUser(@RequestBody DeleteUser user) 
	{
		 return cs.deleteUser(user);
	}
	
	
	
	@GetMapping("/record/{id}")
	public String ViewRecord(@PathVariable String id) 
	{
		ContactDao c = new ContactDao();
		//System.out.println(c.viewAllRecord(id));
		return c.viewAllRecord(id);
		//return ResponseEntity.ok().header("Access-Control-Allow-Origin","http://localhost:4200").body(c.viewAllRecord(id));
	}
}