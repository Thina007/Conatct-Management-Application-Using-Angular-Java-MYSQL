import { Component, OnInit } from '@angular/core';
import { AuthService } from '../_services/auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(public auth:AuthService) { }
  errorMessage:any;
  ngOnInit(): void {
  }

  logout(){
      this.auth.removeToken();
      this.auth.canAccess();
  }

  deleteAco(){
    
    this.auth.deleteAcc()
    .subscribe({
      next:data=>{
        console.log("this..is in adduser form  "+data);
        console.log("Registered idtoken is "+data);
        this.logout();
      },
      error:data=>{
        if (data.error.error.message=="") {
          this.errorMessage = "Unknown error occured when Add User this User account!";
      } else{
        console.log("this.is Error field"+data);
          this.errorMessage = "Unknown error occured when Add User this User account!";
      }
      }
  })
  }

  

}