import { Component, OnInit } from '@angular/core';
import { AuthService } from '../_services/auth.service';
import { Router } from '@angular/router';

interface users {  
  tablename:any;
  name: any;  
  phoneNumber: any;  
  mail: any;  
}  
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  EditDetails:users[]=[];
  constructor(private auth:AuthService) { }
  EditForm(name:any,phoneNumber:any,mail:any)
  {
    sessionStorage.setItem('name',name);
    sessionStorage.setItem('phoneNumber',phoneNumber);
    sessionStorage.setItem('mail',mail);
  }
 
  DeleteUser(name:any)
  {
    sessionStorage.setItem('name',name);
  }
  username:any;
  user: users[] = [];  
  ngOnInit(): void {
    this.auth.canAccess();
    
    if (this.auth.isAuthenticated()) {
        //call user details service
        this.auth.detail().subscribe({
          next:data=>{
            this.username=this.auth.getToken(); 
           
          this.user=<users[]>data;
          console.log(this.user);

          
          },
          error:data=>{
            console.log("Error are Coming: "+data);
            
        }
        })
    }
  }

  logout(){
      //remove token
      this.auth.removeToken();
      this.auth.canAccess();
  }

}

