import { HttpClient } from '@angular/common/http';
import { Token } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private router:Router,private http:HttpClient) { }
 

  isAuthenticated():boolean{
    if (sessionStorage.getItem('token')!==null) {
        return true;
    }
    return false;
  }

  canAccess(){
    if (!this.isAuthenticated()) {
        this.router.navigate(['/']);
    }
  }
  canAuthenticate(){
    if (this.isAuthenticated()) {
      this.router.navigate(['/dashboard']);
    }
  }

  register(name:string,password:string){
     return this.http
      .post(
        'http://localhost:8080/signing',
          {name,password}
      );
  }

  addusers(tablename:string,name:string,phoneNumber:string,mail:string)
  {
    let token = sessionStorage.getItem('token');
    console.log("Table Name is "+token);
    return this.http
    .post(
      'http://localhost:8080/adduser',
    {tablename:token,name,phoneNumber,mail}
    );
  }

  updateuser(tablename:string,name:string,phoneNumber:string,mail:string)
  {
    let token = sessionStorage.getItem('token');
    console.log(tablename);
    return this.http.post('http://localhost:8080/updateuser',{tablename:token,name,phoneNumber,mail});
  }

  deleteuser(tablename:string,name:string)
  {
    let token = sessionStorage.getItem('token');
    return this.http.post('http://localhost:8080/deleteuser',{tablename:token,name});
  }

  storeToken(token:string){
      sessionStorage.setItem('token',token);
  }

  getToken()
  {
    return sessionStorage.getItem('token');
  }

  login(name:string,password:string){
      return this.http
      .post(
          'http://localhost:8080/login',
            {name,password}
      );
  }

  detail(){
    let token = sessionStorage.getItem('token');
    console.log("Login name is: "+token);
    return this.http.get(
        'http://localhost:8080/record/'+token
    );
  }

  deleteAcc()
  {
    
    let token = sessionStorage.getItem('token');
    console.log("hi..this is Deleting Account 2"+token);
    return this.http
      .post(
          'http://localhost:8080/deleteAccount',
            {name:token,password:token}
      );
  }
  //<{us:Array<{tablename:string,name:string,phoneNumber:string,mail:string}>}

  removeToken(){
    sessionStorage.removeItem('token');
  }
}