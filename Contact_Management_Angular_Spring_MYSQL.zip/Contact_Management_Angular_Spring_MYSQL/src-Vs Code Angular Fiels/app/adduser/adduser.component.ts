import { Component,OnInit } from '@angular/core';
import { AuthService } from '../_services/auth.service';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {

  formdata = {name:"",phonenumber:"",email:""};
  submit=false;
  errorMessage="";

  constructor(private auth:AuthService) { }

  ngOnInit(): void {
    
  }

  onSubmit(){
    console.log("AddUser is Working ......");
    this.auth.addusers("",this.formdata.name,this.formdata.phonenumber,this.formdata.email)
    .subscribe({
      next:data=>{
        
        //this.auth.storeToken(data.toString());
        //console.log('Registered idtoken is '+data);
        //this.auth.canAuthenticate();
        console.log("this..is in adduser form  "+data);
        //this.auth.storeToken(data);
        console.log("Registered idtoken is "+data);
        this.auth.canAuthenticate();

      },
      error:data=>{
        if (data.error.error.message=="") {
          this.errorMessage = "Unknown error occured when Add User this User account!";

      } else{
          this.errorMessage = "Unknown error occured when Add User this User account!";
      }
      }
  }).add(()=>{
      console.log('Add User process completed!');
  })
  }

  

}