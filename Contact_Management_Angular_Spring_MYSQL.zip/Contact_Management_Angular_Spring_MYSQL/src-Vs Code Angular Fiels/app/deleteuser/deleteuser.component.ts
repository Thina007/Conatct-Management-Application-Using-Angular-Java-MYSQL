import { Component,OnInit } from '@angular/core';
import { AuthService } from '../_services/auth.service';

@Component({
  selector: 'app-deleteuser',
  templateUrl: './deleteuser.component.html',
  styleUrls: ['./deleteuser.component.css']
})
export class DeleteuserComponent   implements OnInit {

  formdata = {name:sessionStorage.getItem("name")};
  submit=false;
  errorMessage="";
  loading=false;

  constructor(private auth:AuthService) { }

  ngOnInit(): void {
    
  }

  onSubmit(){
    console.log("Delete User is Working ......"+this.formdata.name);
    this.auth.deleteuser("",this.formdata.name!)
    .subscribe({
      next:data=>{
        this.auth.storeToken(data.toString());
        this.auth.canAuthenticate();

      },
      error:data=>{
        if (data.error.error.message=="") {

          this.errorMessage = "Unknown error occured when Delete this User account!";

      } else{
          this.errorMessage = "Unknown error occured when Delete this User account!";
      }
      }
  }).add(()=>{
      this.loading =false;
      console.log('Delete process completed!');
  })
  }

  

}