import { Component,OnInit ,Input} from '@angular/core';
import { AuthService } from '../_services/auth.service';
@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrls: ['./edituser.component.css']
})
export class EdituserComponent  implements OnInit {

  formdata = {name:sessionStorage.getItem("name"),phonenumber:sessionStorage.getItem("phoneNumber"),email:sessionStorage.getItem("mail")};
  submit=false;
  errorMessage="";
  @Input() update:any[]=[]; 

  
  
  constructor(private auth:AuthService) { }

  ngOnInit(): void {
    
  }

  onSubmit(){
    
    console.log("From Update Form "+this.update);
    this.auth.updateuser("",this.formdata.name!,this.formdata.phonenumber!,this.formdata.email!)
    .subscribe({
      next:data=>{
             this.auth.storeToken(data.toString());
              this.auth.canAuthenticate();
      },
      error:data=>{
          if (data.error.error.message=="") {

              this.errorMessage = "Unknown error occured when Update this User account!";

          } else{
              this.errorMessage = "Unknown error occured when Update this User account!";
          }
      }
  }).add(()=>{
      console.log('Update process completed!');
  })
  }

  

}
  